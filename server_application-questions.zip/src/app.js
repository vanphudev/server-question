const express = require("express");
const {rootRouter} = require("./routes/apiRoutes");
const cors = require("cors");
app = express();
require("dotenv").config();

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use(
   cors({
      origin: "vanphudev.id.vn",
      methods: ["GET", "POST", "PUT", "DELETE"],
      allowedHeaders: ["Content-Type", "Authorization"],
   })
);

app.use("/api/v1", rootRouter);

module.exports = app;
